import 'dart:async';

import 'package:flutter/material.dart';
import 'dot_matrix_painter.dart';

class DotMatrixDisplay extends StatefulWidget {
  final double BASE_HEIGHT = 100;
  const DotMatrixDisplay({
    super.key,
    this.background = Colors.red,
    this.foreground = Colors.yellowAccent,
    this.frameColor = Colors.black26,
    this.dotSize = 10,
    this.scaleFactor = 1.0,
    this.opacity = 0.5,
  });
  final Color foreground;
  final Color background;
  final Color frameColor;
  final double dotSize;
  final double scaleFactor;
  final double opacity;

  @override
  State<DotMatrixDisplay> createState() => _DotMatrixDisplayState();
}

class _DotMatrixDisplayState extends State<DotMatrixDisplay>
    with TickerProviderStateMixin {
  int sizeX = 0;
  int sizeY = 0;

  @override
  void initState() {
    dmp = DotMatrixPainter(
      frameColor: widget.frameColor,
      foreground: widget.foreground,
      background: widget.background,
      dotType: type.circle,
      dotSize: widget.dotSize,
      sizeX: sizeX,
      sizeY: (MediaQuery.of(context).size.height / widget.dotSize).floor(),
    );
    sizeX = (MediaQuery.of(context).size.width / widget.dotSize).floor();
    sizeY = (MediaQuery.of(context).size.height / widget.dotSize).floor();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Transform.scale(
      scale: widget.scaleFactor,
      child: CustomPaint(
        painter: dmp,
        child: Container(),
      ),
    );
  }
}
