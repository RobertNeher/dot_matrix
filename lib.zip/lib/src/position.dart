const int originX = 0;
const int originY = 0;

class Position {
  final int x;
  final int y;
  const Position({this.x = originX, this.y = originY});

  Position.origin()
      : x = originX,
        y = originY;

  @override
  String toString() {
    return ('($x, $y)');
  }
}

class Line {
  final Position start;
  final Position end;
  Line(
      {this.start = const Position(x: originX, y: originY),
      this.end = const Position(x: 0, y: 0)});
}
