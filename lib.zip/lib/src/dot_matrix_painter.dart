import 'package:flutter/material.dart';

enum DotType { square, circle }

class Dot {
  final Offset offset;
  final Color color;
  final DotType dotType;

  Dot(
      {this.offset = Offset.zero,
      this.color = Colors.transparent,
      this.dotType = DotType.circle});
}

class DotMatrixPainter extends CustomPainter {
  final double dotSize;
  final DotType dotType;
  Color frameColor;
  Color foreground;
  Color background;
  final int sizeX;
  final int sizeY;
  List<List<Dot>>? dotMatrix;
  double offsetX = 0;
  double offsetY = 0;
  double dotDistance = 0;
  Paint _paint = Paint();

  DotMatrixPainter({
    this.foreground = Colors.red,
    this.background = Colors.yellowAccent,
    this.frameColor = Colors.black26,
    this.sizeX = 100,
    this.sizeY = 40,
    this.dotType = DotType.circle,
    this.dotSize = 10,
    this.dotMatrix,
  }) {
    offsetX = dotSize / 2 + strokeWidth();
    offsetY = dotSize / 2 + strokeWidth();
  }

  @override
  void paint(Canvas canvas, Size size) {
    _paint.style = PaintingStyle.stroke;
    _paint.strokeWidth = strokeWidth();
    _paint.color = frameColor;

    canvas.drawRect(
        Rect.fromCenter(
            center: Offset(size.width / 2, size.height / 2),
            height: size.height,
            width: size.width),
        _paint);

    _paint.style = PaintingStyle.fill;
    _paint.strokeWidth = dotSize / 4;
    _paint.color = background;

    for (int x = 0; x < sizeX - sizeCorrection(); x++) {
      for (int y = 0; y < sizeY - sizeCorrection(); y++) {
        if (dotMatrix![x][y].dotType == DotType.circle) {
          canvas.drawCircle(dotMatrix![x][y].offset, dotSize / 2, _paint);
        } else if (dotMatrix![x][y].dotType == DotType.square) {
          canvas.drawRect(
              Rect.fromCenter(
                  center: dotMatrix![x][y].offset,
                  width: dotSize,
                  height: dotSize),
              _paint);
        }
      }
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }

  double distance() {
    return dotDistance = dotSize / 10;
  }

  double strokeWidth() {
    return dotSize / 4;
  }

  int sizeCorrection() {
    return (strokeWidth() / 3).ceil() + 1;
  }
}
