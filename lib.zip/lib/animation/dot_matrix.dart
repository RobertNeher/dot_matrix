import 'package:dot_matrix_display/src/dot_matrix_painter.dart';
import 'package:flutter/material.dart';

enum type { square, circle }

class Dot {
  final Offset offset;
  final Color color;
  final type dotType;

  Dot(
      {this.offset = Offset.zero,
      this.color = Colors.transparent,
      this.dotType = type.circle});
}

class DotMatrix extends StatefulWidget {
  final int sizeX;
  final int sizeY;
  final double dotSize;
  final DotType dotType;
  double offsetX;
  double offsetY;
  final double dotDistance;
  final double scaleFactor;
  Color frameColor;
  Color foreground;
  Color background;
  final double opacity;
  List<List<Dot>>? dotMatrix;

  DotMatrix(
      {this.sizeX = 40,
      this.sizeY = 40,
      this.dotSize = 10,
      this.dotType = DotType.circle,
      this.offsetX = 0,
      this.offsetY = 0,
      this.dotDistance = 0,
      this.scaleFactor = 1,
      this.frameColor = Colors.purpleAccent,
      this.foreground = Colors.red,
      this.background = Colors.black12,
      this.opacity = 1.0,
      this.dotMatrix = const []});

  @override
  State<DotMatrix> createState() => _DotMatrixState();
}

class _DotMatrixState extends State<DotMatrix> with TickerProviderStateMixin {
  @override
  void initState() {
    widget.dotMatrix = List.generate(widget.sizeX,
        (index) => List<Dot>.generate(widget.sizeY, Dot(), growable: false),
        growable: false);
    widget.offsetX = widget.dotSize / 2 + strokeWidth();
    widget.offsetY = widget.dotSize / 2 + strokeWidth();

    widget.foreground = widget.foreground.withOpacity(widget.opacity);
    widget.background = widget.background.withOpacity(widget.opacity);
    widget.frameColor = widget.frameColor.withOpacity(widget.opacity);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Transform.scale(
        scale: widget.scaleFactor,
        child: CustomPaint(
          painter: DotMatrixPainter(
            background: widget.background,
            foreground: widget.foreground,
            frameColor: widget.frameColor,
            sizeX: widget.sizeX,
            sizeY: widget.sizeY,
            dotType: widget.dotType,
            dotSize: widget.dotSize,
            dotMatrix: widget.dotMatrix,
          ),
          child: Container(),
        ));
  }

  setDot(posX, posY) {
    for (int x = 0; x < widget.sizeX - sizeCorrection(); x++) {
      for (int y = 0; y < widget.sizeY - sizeCorrection(); y++) {
        widget.dotMatrix[x][y] = Dot(
            color: (x == posX && y == posY)
                ? widget.foreground
                : widget.background,
            dotType: type.circle,
            offset: Offset(
              widget.offsetX + x * (widget.dotSize + distance()),
              widget.offsetY + y * (widget.dotSize + distance()),
            ));
      }
    }
  }

  resetMatrix() {
    widget.dotMatrix.value = List<List<Dot>>.generate(
        widget.sizeX,
        (index) =>
            List<Dot>.generate(widget.sizeY, (index) => Dot(), growable: false),
        growable: false);

    setDot(-1, -1);
  }

  double distance() {
    return widget.dotSize / 10;
  }

  double strokeWidth() {
    return widget.dotSize / 4;
  }

  int sizeCorrection() {
    return (strokeWidth() / 3).ceil() + 1;
  }
}
